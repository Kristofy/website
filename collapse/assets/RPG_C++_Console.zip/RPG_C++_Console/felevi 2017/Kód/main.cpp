#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <string>
#include "otlotto.h"
#include "kitalal.h"
#include "akasztoffa.h"
#include "felbont.h"
using namespace std;

struct alap{
string nev;
string jelszo;
int penz;
};
int ffelbont();
int otoslotto(int penz);
int akasztofa();
int lotto(int penz);
int szamkitalalos(int penz);
int szkitalalos(int penz);
int belepett(int fszam,vector<alap> &f);
int main()
{
    ofstream fileiras;
    bool jszo=1;
    bool talalat=1;
    bool mehet=1;
    vector <alap> f;
    int folyt;
    string ell;
    alap beolv;
     ofstream fout;
    //beolvas
ifstream fin;
//dekod jon ide
fin.open("adatok.txt");
while(!fin.eof()){
        fin>>beolv.nev>>beolv.jelszo>>beolv.penz;
    f.push_back(beolv);
}
fin.close();
//kiiratas
while(1){
        mehet=1;
        system("cls");
cout<<"kilepes\t\t->0"<<endl;
cout<<"regisztracio\t->1"<<endl;
cout<<"bejelenkezes\t->2"<<endl;
cin>>folyt;
switch(folyt){
case 0 :

    fileiras.open("adatok.txt");
    fileiras<<f[0].nev<<" "<<f[0].jelszo<<" "<<1000000000;
    for(unsigned int i=1;i<f.size();i++){
     fileiras<<"\n"<<f[i].nev<<" "<<f[i].jelszo<<" "<<f[i].penz;
    }
    fileiras.close();
    system("cls");
cout<<"viszont latasra"<<endl;
return 0;
    break;
case 1 :
system("cls");
cout<<"Adja meg a felhasznalonevet:\t";
cin>>beolv.nev;
for(unsigned int i=0;i<f.size();i++){
    if(beolv.nev==f[i].nev){
            cout<<"Ez a felhasznalonev mar letezik!"<<endl;
    system("pause");
    mehet=0;
    break;
    }
}
if (mehet==0){
    break;
}
cout<<"Megegyszer:\t\t\t";
cin>>ell;
if(beolv.nev==ell){
    cout<<"Adjon meg egy jelszot:\t\t";
    cin>>beolv.jelszo;

    fout.open("adatok.txt",ios::in | ios::ate);
    fout<<"\n"<<beolv.nev<<" "<<beolv.jelszo<<" "<<1000;
    fout.close();
    beolv.penz=1000;
    f.push_back(beolv);
}else{
cout<<"A felhasznalonev nem egyezik meg!"<<endl;
system("pause");
}

break;


case 2 :
    system("cls");
cout<<"Felhasznalonev:\t";
cin>>ell;
talalat=1;
jszo=1;
for(unsigned int i=0;i<f.size();i++){
    if(ell==f[i].nev){
        cout<<"Jelszo:\t\t";
        cin>>ell;
        if(ell==f[i].jelszo){
                talalat=1;
            system("cls");
            cout<<"Sikeres belepes"<<endl;
            belepett(i,f);
            break;
        }else{
        cout<<"Helytelen jelszo!"<<endl;
        jszo=0;
        system("pause");
        break;
        }
    }else{
        talalat=0;}
}
if(jszo==0){
    break;
}
if(talalat==0){
    cout<<"Ez a felhasznalonev nem letezik!"<<endl;
    system("pause");
    break;
}
break;
    default :
 break;
}


}
}

int belepett(int fszam,vector<alap> &f){
    bool volt=true;
    string nevvalt;
    int valaszt;
    int profil;
    int torles;
    int jatekv;
    int bealittasok;
    if(f[fszam].penz>0){
      cout<<"Kijelentkezes\t->0\t\t\t"<<f[fszam].penz<<"$"<<endl;
cout<<"alkalmazasok\t->1"<<endl;
cout<<"Profil\t\t->2"<<endl;
cin>>valaszt;
    }else{
    cout<<"On csodbe ment!"<<endl;
    cout<<"A fiokja automatikusan torlesre kerul!"<<endl;
    f.erase(f.begin()+fszam);
    system("pause");
    return 0;
    }

switch(valaszt){
case 0:
    system("cls");
    cout<<"Sikeres kijelentkezes"<<endl;
    system("pause");
    return 0;
case 1:
    system("cls");
    cout<<"vissza\t\t->0"<<endl;
    cout<<"5os lotto\t->1"<<endl;
    cout<<"szamkitalalos\t->2"<<endl;
    cout<<"akasztofa\t->3"<<endl;
    cout<<"primtenyezos felbontas\t->4"<<endl;
    cin>>jatekv;
    switch(jatekv){//jatekok!!!
case 1:
    system("cls");
    f[fszam].penz+=lotto(f[fszam].penz);
    system("cls");
    break;
case 2:
    system("cls");
    f[fszam].penz+=szkitalalos(f[fszam].penz);
    system("cls");
    break;
case 3:
    //////////////////////////////////////////
    akasztoffa aObj;
    aObj.akasztofa();
    system("cls");
    break;
case 4:
    system("cls");
    felbont fObj;
    fObj.ffelbont();
    system ("pause");
    system ("cls");

default:
    system("cls");
    break;
    }

    break;
    case 2:
        system("cls");
        cout<<"\tAdatok"<<endl;
        cout<<"Felhasznalonev:\t"<<f[fszam].nev<<endl;
        cout<<"Jelszo\t\t"<<f[fszam].jelszo<<endl;
        cout<<"Penz:\t\t"<<f[fszam].penz<<"$"<<endl;
        cout<<"Vissza\t\t->0"<<endl;
        cout<<"Bealittasok:\t->1"<<endl;
        cin>>profil;
        switch(profil){
    case 0:
        system("cls");
        belepett(fszam,f);
        return 0;
        break;
    case 1:
        //beallitasook
        system("cls");
        cout<<"vissza\t\t\t\t->0"<<endl;
        cout<<"Nev megvaltoztatasa\t\t->1"<<endl;
        cout<<"Jelszo megvaltoztatasa\t\t->2"<<endl;
        cout<<"Fiok torlese\t\t\t->3"<<endl;
        cin>>bealittasok;
        switch(bealittasok){
    case 1:

    do{
            volt=false;
              system("cls");
    cout<<"uj nev:\t";
    cin>>nevvalt;
    for(unsigned int i=0;i<f.size();i++){
        if(nevvalt==f[i].nev&&fszam!=i){
            cout<<"Ez a felhasznalonev mar letezik!\nProbalja ujra!"<<endl;
    system("pause");
            volt=true;
                break;
        }
    }
    if(volt==false){
        f[fszam].nev=nevvalt;
    }
    }while(volt!=false);
system("cls");
cout<<"Nev sikeresen megvaltoztatval"<<endl;
system("pause");
system("cls");
    break;
        case 2:
        system("cls");
    cout<<"uj jelszo:\t";
    cin>>f[fszam].jelszo;
    system("cls");
    cout<<"Jelszo sikeresen megvaltoztatva"<<endl;
    system("pause");
system("cls");
            break;
        case 3 :
            system("cls");
            cout<<"biztos hogy torolni szeretne a fiokjat?"<<endl;
            cout<<"nem\t->0\t\tigen\t->1"<<endl;
            cin>>torles;
            if(torles==1){
                f.erase(f.begin()+fszam);
                cout<<"A fiokodat sikresen toroltuk"<<endl;
                system("pause");
                return 0;
            }
            system("cls");
                break;
        default:
            system("cls");
            break;
        }
        break;
    default:
            system("cls");

        break;
        }


    break;
    default:
        break;
}
belepett(fszam, f);
}


int lotto(int penz){
    int a;
otlotto lottoObj;
a=lottoObj.otoslotto(penz);
return a;
}


int szkitalalos(int penz){
    int a;
kitalal kitalalObj;
a=kitalalObj.szamkitalalos(penz);
return a;
}

