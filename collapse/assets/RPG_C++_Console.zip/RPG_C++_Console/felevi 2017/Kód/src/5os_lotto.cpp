#include "5os_lotto.h"
#include <cstdlib>
#include <ctime>
#include <string>
#include <iostream>


using namespace std;

5os_lotto::5os_lotto()
{





string nyertOsszeg;
    srand(time(0));
int a=rand();
int talalat=0;
int nyeroszamok[5];
bool volt;
for (int i=0;i<5;i++){
        do{
    nyeroszamok[i]=rand()%90;
    volt=false;
    for (int k=0;k<i;k++){
    if (nyeroszamok[i]==nyeroszamok[k])
        volt=true;}
        }while(volt);
        }
int tippek[5];
bool mehet=true;
cout<<"Adjon meg 5 szamot 1 es 90 kozott!"<<endl;
for (int i=0;i<5;i++){
    cout<<"adja meg az "<<i+1<<". tippet"<<endl;                        // tippek bekerese
    cin>>tippek[i];

    if(tippek[i]>90){
    cout<<"Hiba!"<<endl;                //tippek ellenorzese
    cout<<"A megadott szamoknak 1 es 90 kozott kell lennie!"<<endl;
    cout<<"probalja ujra"<<endl;
    i--;
    }

    for (int k=0;k<i;k++){

if(tippek[i]==tippek[k]){                 //tippek ellenorzese
    cout <<"Hiba!"<<endl;
    cout<<"Ne adjon meg ugyanolyan szamot amit egyszer mar megadott!"<<endl;
    cout<<"probalja ujra!"<<endl;
    i--;
    break;
}
}
}
for (int i=0;i<5;i++){
    cout<<"A(z) "<<i+1<<". nyeroszam: "<< nyeroszamok[i]<<endl;
}
for (int i=0;i<5;i++){
    for(int k=0;k<5;k++){
        if (nyeroszamok[i]==tippek[k]){
            talalat+=1;
        }
    }
}
switch (talalat){
case 2:
    nyertOsszeg="1220 ft";
    break;
case 3:
    nyertOsszeg="14 ezer 200 ft";
    break;
case 4:
    nyertOsszeg="1 millio 148 ezer 300 ft";
    break;
case 5:
    nyertOsszeg="1066 millio ft";
    break;
default:
    nyertOsszeg="0 ft";
    break;
}
cout<<"Talalatok szama: "<<talalat<<endl;
cout<<"a nyert osszeg: "<<nyertOsszeg<<endl;
if (talalat==5){
    cout<<"Gratulallunk megnyerte a fonyeremenyt!!"<<endl;
}

    for (int i=0;i<=5;i++){
tippek[i]=0;
    }
  pause();


}

5os_lotto::~5os_lotto()
{
    //dtor
}
