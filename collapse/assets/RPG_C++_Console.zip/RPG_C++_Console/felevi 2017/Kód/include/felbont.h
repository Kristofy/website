#ifndef FELBONT_H
#define FELBONT_H


class felbont
{
    public:
        int ffelbont();


    protected:

    private:
};

#endif // FELBONT_H
