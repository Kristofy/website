#ifndef AKASZTOFFA_H
#define AKASZTOFFA_H


class akasztoffa
{
    public:

int akasztofa();
    protected:

    private:
};

#endif // AKASZTOFFA_H
