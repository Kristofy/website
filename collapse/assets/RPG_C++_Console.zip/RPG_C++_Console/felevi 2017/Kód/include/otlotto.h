#ifndef OTLOTTO_H
#define OTLOTTO_H


class otlotto
{
    public:
       int otoslotto(int penz);

    protected:

    private:
};

#endif // OTLOTTO_H
