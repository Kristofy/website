#include "felbont.h"
#include <iostream>

using namespace std;

int felbont::ffelbont()
{
    cout<<"Adja meg a felbontani kivant szamot!"<<endl;
int64_t a;
int64_t valt;
cin>>a;
valt=a;
for(int64_t i=2;i<=a;i++){
while(valt%i==0){
    cout<<valt<<"\t|\t"<<i<<endl;
    valt=valt/i;
    if(valt<=1){
           return 0;
    }
}
}

}


