#include "kitalal.h"
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <conio.h>

using namespace std;

int kitalal::szamkitalalos(int penz)
{
  int vegosszeg=0;
  string ujra="igen";
    do{
            system("CLS");
        if (ujra=="igen"){
        srand(time(0));
        int szam=rand()%100+1;
        int tipp;
        int valasz;

        int probalkozasok=0;
        bool mehet=true;
    cout<<"A jatek menete:\t\t\t\t penze:\t"<<penz<<"$"<<endl;
    cout<<"A leheto legkevesebb probalkozasbol (maximum 10)probalja meg "<<endl;
    cout<<"kitalalni a szamot! (A szam 1 es 100 kozott van!) "<<endl;
    cout<<"A jatek megkezdese es minden fordulo 100$ ba kerul"<<endl;
    cout<<"Vissza:\t\t\t->0"<<endl;
    cout<<"Neremenyek:\t\t->1"<<endl;
    cout<<"Folytatas:\t\t->2"<<endl;
    cin>>valasz;
    switch(valasz){
case 1:
    system("cls");
    cout<<"1 probabol\t 5 000 000$ "<<endl;
    cout<<"2 probabol\t 1 000 000$ "<<endl;
    cout<<"3-4 probabol\t 50 000$ "<<endl;
    cout<<"5-6 probabol\t 1 000$ "<<endl;
    cout<<"7-10 probabol\t 50$ "<<endl;
    cout<<"10 felett\t -1 000$ "<<endl;
    cout<<endl;
    cout<<"Vissza\t\t->0"<<endl;
    cout<<"folytatas\t->1"<<endl;
    cin>>valasz;
    if(valasz!=1){
        return vegosszeg;
    }
    break;
case 2:
    break;
default:
    system("cls");
    return vegosszeg;
    }
    system("cls");
    vegosszeg-=100;
    if (penz+vegosszeg<1){
            system("cls");
        cout<<"Nincs eleg penze a folytatashoz!"<<endl;
        system("pause");
    return vegosszeg;
    }
    for(int i=1;szam!=tipp;i++){
            if (mehet==true){
            cout<<"Adja meg a(z) "<<i<<".tippet!"<<endl;
    cin>>tipp;
        if (szam<tipp){
            cout<<"Tipelj kissebet!"<<endl;
            probalkozasok+=1;
        }
        if (szam>tipp){
            cout<<"Tippelj nagyobbat!"<<endl;
            probalkozasok+=1;
        }
        if (szam==tipp){
                probalkozasok++;
            cout<<"Gratulallok kitalalta a szamot "<<probalkozasok<<"db probalkozasbol."<<endl;
            switch(probalkozasok){
        case 1:
            cout<<"nyert osszeg 5 000 000 $"<<endl;
            vegosszeg+=5000000;
            break;
            case 2:
            cout<<"nyert osszeg 1 000 000 $"<<endl;
            vegosszeg+=1000000;
            break;
            case 3:
            cout<<"nyert osszeg 50 000 $"<<endl;
            vegosszeg+=50000;
            break;
            case 4:
            cout<<"nyert osszeg 50 000 $"<<endl;
            vegosszeg+=50000;
            break;
            case 5:
            cout<<"nyert osszeg 1 000 $"<<endl;
            vegosszeg+=1000;
            break;
            case 6:
            cout<<"nyert osszeg 1 000 $"<<endl;
            vegosszeg+=1000;
            break;
            case 7:
            cout<<"nyert osszeg 50 $"<<endl;
            vegosszeg+=50;
            break;
              case 8:
            cout<<"nyert osszeg 50 $"<<endl;
            vegosszeg+=50;
            break;
              case 9:
            cout<<"nyert osszeg 50 $"<<endl;
            vegosszeg+=50;
            break;
              case 10:
            cout<<"nyert osszeg 50 $"<<endl;
            vegosszeg+=50;
            break;
            }
                       }
        if (probalkozasok>=10){
            mehet=false;
            szam=tipp;
        }
                              }
                                }
        if (mehet==false){
                system("CLS");
            cout<<"Vesztettel!"<<endl;
            cout<<"Nem sikerult kitalalni a szamot!"<<endl;
            cout<<"Vesztett osszeg 1000$"<<endl;
            vegosszeg-=1000;
        }
        penz+=vegosszeg;
         system("pause");
        }

            system("CLS");
        cout<<"Szeretne megprobalni megegyszer?  igen/nem"<<endl;
        getline (cin,ujra);
        }while(ujra!="nem");
        return vegosszeg;




}
