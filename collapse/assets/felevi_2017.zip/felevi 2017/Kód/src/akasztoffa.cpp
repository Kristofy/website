#include "akasztoffa.h"
#include <iostream>
#include <cstdlib>
#include <conio.h>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

int akasztoffa::akasztofa()
{
    setlocale(LC_ALL,"hun");
    vector <char> v;
    vector <char> vec;
    string szo;
    int szamlalo=0;
    string randszo;
    char tipp;
     ifstream fin;
        fin.open("szavak.txt");
for(int i=0;i<rand()%110;i++){
    fin>>randszo;
}
fin.close();
            int a=0,eltalalt=0,hp=10;
            char eredeti[randszo.length()];
            char talalgatas[randszo.length()];



    bool mehet=true;
    system("cls");
    cout<<"A szavak nem tartalmazhatnak ekezetet!"<<endl;
    cout<<"vissza\t\t->0"<<endl;
    cout<<"random szo\t->1"<<endl;
    cout<<"megadott szo\t->2"<<endl;
    int dontes;
    cin>>dontes;
    system("cls");
    switch(dontes){
    case 1:



            for (int i=0;i<randszo.length();i++){
                eredeti[i]=randszo.at(i);
            }
             for (int i=0;i<randszo.length();i++){
                talalgatas[i]='_';
            }
            while(mehet){
                    system("cls");
                 for (int i=0;i<randszo.length();i++){
                    cout<<talalgatas[i]<<" ";
                 }
                 cout<<"\telet: "<<hp<<endl;
                 cin>>tipp;
                  for (int i=0;i<randszo.length();i++){
                     if (tipp==eredeti[i]){
                        for(int k=0;k<v.size();k++){
                            if(tipp!=v[k]){
                                szamlalo++;
                            }
                        }
                        if(szamlalo==v.size()){
                             talalgatas[i]=tipp;
                    a++;
                    eltalalt++;
                        }
                        szamlalo=0;
                }
            }
            v.push_back(tipp);
            if(a==0){
                hp--;
            }
            a=0;
            if(hp==0){
                    system("cls");
                cout<<"ez most nem sikerult!\nA szo amit ki kellett volna talalni :"<<endl;
                cout<<randszo<<endl;
                system ("pause");
                return 0;
            }
              if(eltalalt==randszo.length()){
                    system("cls");
               system("cls");
                 for (int i=0;i<randszo.length();i++){
                    cout<<talalgatas[i]<<" ";
                 }
                cout<<"\nGaratulallunk sikerult kitalalni"<<endl;
                system ("pause");
                return 0;
            }

            }
        break;
default:
    system("cls");
    break;
    }

    if(dontes==2){
            szamlalo=0;
                    cout<<"adja meg a kitalalni kivant szot :"<<endl;
            cin>>szo;
int x=0,y=0,elet=10;
            char megoldas[szo.length()];
            char tippek[szo.length()];
            for (int i=0;i<szo.length();i++){
                megoldas[i]=szo.at(i);
            }
             for (int i=0;i<szo.length();i++){
                tippek[i]='_';
            }
            while(mehet){
                    system("cls");
                 for (int i=0;i<szo.length();i++){
                    cout<<tippek[i]<<" ";
                 }
                 cout<<"\t\telet: "<<elet<<endl;
                 cin>>tipp;
                    for (int i=0;i<szo.length();i++){
                     if (tipp==megoldas[i]){
                        for(int k=0;k<vec.size();k++){
                            if(tipp!=vec[k]){
                                szamlalo++;
                            }
                        }


                        if(szamlalo==vec.size()){
                             tippek[i]=tipp;
                    x++;
                    y++;
                        }
                        szamlalo=0;
                }

            }
            vec.push_back(tipp);
            if(x==0){

                elet--;
            }
            x=0;
            if(elet==0){
                    system("cls");
                cout<<"ez most nem sikerult!\nA szo amit ki kellett volna talalalni :"<<endl;
                for (int i=0;i<szo.length();i++){
                cout<<megoldas[i]<<" ";
            }
            cout<<endl;
                system ("pause");
                return 0;
            }
            if(y==szo.length()){
                    system("cls");
               system("cls");
                 for (int i=0;i<szo.length();i++){
                    cout<<tippek[i]<<" ";
                 }
                cout<<"\nGaratulallunk sikerult kitalalni"<<endl;
                system ("pause");
                return 0;

            }
            }
            }


}
