#include "otlotto.h"
#include <cstdlib>
#include <ctime>
#include <string>
#include <iostream>


using namespace std;

int otlotto::otoslotto(int penz)
{
string nyertOsszeg;
int vegosszeg=0;
int korokszama;
    srand(time(0));
int a=rand();
int talalat=0;
int seged;
int nyeroszamok[5];
bool volt=false;

int tippek[5];
bool mehet=true;
cout<<"Adjon meg 5 szamot 1 es 90 kozott!"<<endl;
for (int i=0;i<5;i++){
    cout<<"adja meg az "<<i+1<<". tippet"<<endl;                        // tippek bekerese
    cin>>tippek[i];

    if(tippek[i]>90){
    cout<<"Hiba!"<<endl;                //tippek ellenorzese
    cout<<"A megadott szamoknak 1 es 90 kozott kell lennie!"<<endl;
    cout<<"probalja ujra"<<endl;
    i--;
    }

    for (int k=0;k<i;k++){

if(tippek[i]==tippek[k]){                 //tippek ellenorzese
    cout <<"Hiba!"<<endl;
    cout<<"Ne adjon meg ugyanolyan szamot amit egyszer mar megadott!"<<endl;
    cout<<"probalja ujra!"<<endl;
    i--;
    break;
}
}

}
do{
        system("cls");
cout<<"hany huzasra szertne feltenni( 1 huzas 6$ ,max 5 huzas)"<<endl;
cout<<"jelenleg rendelkezesere allo osszeg:\t"<<penz<<"$"<<endl;
cout<<"Vissza\t\t->0"<<endl;
cout<<"korok szama:\t";
cin>>korokszama;
while(korokszama*6>penz){
        system("cls");
    cout<<"Ez meghaladja a keretet"<<endl;
    cout<<"probalja ujra!"<<endl;
    cin>>korokszama;
}
if(korokszama>5){
    cout<<"maximum 5 huzas engedejezett!"<<endl;
    cout<<"probalja ujra!"<<endl;
    system("pause");
    system("cls");
}
}while(korokszama>5);
vegosszeg-=korokszama*6;
for (int y=0;y<korokszama;y++){
        system("cls");
        cout<<"az "<<y+1<<". kor "<<endl;

        for (int x=0;x<5;x++){
        do{
    nyeroszamok[x]=rand()%90+1;
    volt=false;
    for (int g=0;g<x;g++){
    if (nyeroszamok[x]==nyeroszamok[g])
        volt=true;}
        }while(volt);
        }
    for(int xy=0;xy<4;xy++){
        for(int c=xy+1;c<5;c++){
                if(nyeroszamok[xy]>nyeroszamok[c]){
            seged=nyeroszamok[xy];
            nyeroszamok[xy]=nyeroszamok[c];
            nyeroszamok[c]=seged;
            }
        }
    }

cout<<"\ttippek\t\t\tnyeroszamok"<<endl;
for (int i=0;i<5;i++){
    cout<<"A(z) "<<i+1<<". tipp: "<< tippek[i]<<"\t\tA(z) "<<i+1<<". nyeroszam: "<< nyeroszamok[i]<<endl;
}
for (int i=0;i<5;i++){
    for(int k=0;k<5;k++){
        if (nyeroszamok[i]==tippek[k]){
            talalat+=1;
        }
    }
}

switch (talalat){
case 2:
    nyertOsszeg="4$";
    vegosszeg+=4;
    break;
case 3:
    nyertOsszeg="50$";
    vegosszeg+=50;
    break;
case 4:
    nyertOsszeg="4 300$";
    vegosszeg+=4300;
    break;
case 5:
    nyertOsszeg="4 000 000$";
    vegosszeg+=4000000;
    break;
default:
    nyertOsszeg="0 ft";
    break;
}

cout<<"Talalatok szama: "<<talalat<<endl;
cout<<"a nyert osszeg: "<<nyertOsszeg<<endl;
if (talalat==5){
    cout<<"Gratulallunk megnyerte a fonyeremenyt!!"<<endl;
}
    talalat=0;
  system("pause");



}
 for (int i=0;i<=5;i++){
tippek[i]=0;
    }
return vegosszeg;
}
