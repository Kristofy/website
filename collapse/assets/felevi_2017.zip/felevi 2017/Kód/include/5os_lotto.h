#ifndef 5OS_LOTTO_H
#define 5OS_LOTTO_H


class 5os_lotto
{
    public:
        5os_lotto();

    protected:

    private:
};

#endif // 5OS_LOTTO_H
