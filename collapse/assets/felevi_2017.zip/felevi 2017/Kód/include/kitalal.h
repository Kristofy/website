#ifndef KITALAL_H
#define KITALAL_H


class kitalal
{
    public:
        int szamkitalalos(int penz);

    protected:

    private:
};

#endif // KITALAL_H
